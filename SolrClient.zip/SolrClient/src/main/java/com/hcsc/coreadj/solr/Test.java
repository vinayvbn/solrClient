package com.hcsc.coreadj.solr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.MapSolrParams;

public class Test {
	public static void main(String[] args) throws SolrServerException, IOException {
		List ls = new ArrayList<>();	 
		SolrClient sc = new HttpSolrClient.Builder("http://DVTP6473:8983/solr")
				.build();
		final Map<String, String> queryParamMap = new HashMap<String, String>();
		SolrQuery query = new SolrQuery();
		query.setQuery("AOM2:*Code");
		//query.addFilterQuery("Aom2:*");
		//query.setFields("Aom2");
		queryParamMap.put("q", "AOM2:from*");
		queryParamMap.put("f1", "AOM2,XOM");
		MapSolrParams queryParams = new MapSolrParams(queryParamMap);
		 QueryResponse response = sc.query("pli",query);
		 SolrDocumentList documents = response.getResults();
		 for (SolrDocument solrDocument : documents) {
			
		}
		 System.out.println(documents);
	}
}
