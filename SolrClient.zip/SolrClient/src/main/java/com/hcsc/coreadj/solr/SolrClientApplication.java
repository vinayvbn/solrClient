package com.hcsc.coreadj.solr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import com.fasterxml.jackson.annotation.JsonInclude;

@SpringBootApplication
@ComponentScan(basePackages = { "com.hcsc.coreadj.solr" })
public class SolrClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolrClientApplication.class, args);
	}

	@Bean
	public Jackson2ObjectMapperBuilder objectMapperBuilder() {
		Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
		builder.serializationInclusion(JsonInclude.Include.NON_NULL);
		builder.serializationInclusion(JsonInclude.Include.NON_EMPTY);
		builder.indentOutput(true);
		return builder;
	}

	@Bean
	public HttpMessageConverter jacksonMessageConverter() {
		return new MappingJackson2HttpMessageConverter(objectMapperBuilder().build());
	}
}
