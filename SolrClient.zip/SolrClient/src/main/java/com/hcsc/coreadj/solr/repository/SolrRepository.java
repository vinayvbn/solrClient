package com.hcsc.coreadj.solr.repository;

import java.util.List;

import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;

import com.hcsc.coreadj.solr.model.MappingResponse;

public interface SolrRepository extends SolrCrudRepository<MappingResponse, String> {
	@Query(value = "business:*?0*", fields = { "XOM", "BOM", "AOM2" })
	List<MappingResponse> findBybusiness(String business);

}
