package com.hcsc.coreadj.solr.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.solr.core.DefaultQueryParser;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.data.solr.core.query.Field;
import org.springframework.data.solr.core.query.Query;
import org.springframework.data.solr.core.query.SimpleField;
import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.data.solr.core.query.result.SolrResultPage;
import org.springframework.stereotype.Service;

import com.hcsc.coreadj.solr.model.MappingResponse;
import com.hcsc.coreadj.solr.repository.SolrRepository;

@Service
public class SolrClientService {
	@Value("${solr.engine.url}")
	private String solrUri;

	@Autowired
	private SolrRepository repository;

	@Resource
	private SolrTemplate solrTemplate;

	public SolrClientService() {

	}

	public List<MappingResponse> getAll() {
		SolrResultPage<MappingResponse> sr = (SolrResultPage<MappingResponse>) repository.findAll();

		return sr.getContent();
	}

	public Map<String, List<MappingResponse>> getXomBomAom2ByBusinessField(String businessField) {
		Query query = new SimpleQuery("business:" + "\"+" + businessField + "+\"");
		Map<String, List<MappingResponse>> resultMap = new HashMap<>();
		resultMap.clear();
		DefaultQueryParser dp = new DefaultQueryParser();
		dp.getQueryString(query);
		List<MappingResponse> medicareList = null;
		List<MappingResponse> pliList = null;
		List<MappingResponse> masterList = null;
		Page<MappingResponse> meidcareQuery = solrTemplate.queryForPage("medicare", query, MappingResponse.class);
		medicareList = meidcareQuery.getContent();
		Page<MappingResponse> masterQuery = solrTemplate.queryForPage("master", query, MappingResponse.class);
		masterList = masterQuery.getContent();
		Page<MappingResponse> pliQuery = solrTemplate.queryForPage("pli", query, MappingResponse.class);
		pliList = pliQuery.getContent();
		addResultToMap(resultMap, pliList, masterList, medicareList);
		return resultMap;
	}

	private void addResultToMap(Map<String, List<MappingResponse>> resultMap, List<MappingResponse> pliList,
			List<MappingResponse> masterList, List<MappingResponse> medicareList) {

		resultMap.put("medicare", medicareList);
		resultMap.put("master", masterList);
		resultMap.put("pli", pliList);
		resultMap.values().removeAll(Collections.singleton(null));

	}

	public List<String> getAllBusinessFields() {
		Query query = new SimpleQuery("*:*");
		Field f = new SimpleField("business");
		query.addProjectionOnField(f);
		query.setRows(100);
		List<MappingResponse> medicareList = null;
		Page<MappingResponse> page = solrTemplate.queryForPage("master", query, MappingResponse.class);
		medicareList = page.getContent();
		List<String> bussinessFields = new ArrayList<String>();
		for (MappingResponse object : medicareList) {

			if (Objects.nonNull(object)) {

				bussinessFields.add(object.getBusiness());
			}

		}

		return bussinessFields;
	}

}
