package com.hcsc.coreadj.solr.model;

import org.apache.solr.client.solrj.beans.Field;
import org.springframework.data.annotation.Id;
import org.springframework.data.solr.core.mapping.Indexed;
import org.springframework.data.solr.core.mapping.SolrDocument;

@SolrDocument(collection = "pli")
public class MappingResponse {

	@Id
	@Field
	@Indexed(name = "id")
	private String id;
	@Field
	@Indexed(name = "business")
	private String business;
	@Field
	@Indexed(name = "AOM2")
	private String AOM2;
	@Field
	@Indexed(name = "PWIP")
	private String PWIP;
	@Field
	@Indexed(name = "VSAM_Field")
	private String VSAM_Field;
	@Field
	@Indexed(name = "XOM")
	private String XOM;
	@Field
	@Indexed(name = "BOM")
	private String BOM;
	@Field
	@Indexed(name = "Business_Definition")
	private String Business_Definition;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getAOM2() {
		return AOM2;
	}

	public void setAOM2(String aOM2) {
		AOM2 = aOM2;
	}

	public String getPWIP() {
		return PWIP;
	}

	public void setPWIP(String pWIP) {
		PWIP = pWIP;
	}

	public String getVSAM_Field() {
		return VSAM_Field;
	}

	public void setVSAM_Field(String vSAM_Field) {
		VSAM_Field = vSAM_Field;
	}

	public String getXOM() {
		return XOM;
	}

	public void setXOM(String xOM) {
		XOM = xOM;
	}

	public String getBOM() {
		return BOM;
	}

	public void setBOM(String bOM) {
		BOM = bOM;
	}

	public String getBusiness_Definition() {
		return Business_Definition;
	}

	public void setBusiness_Definition(String business_Definition) {
		Business_Definition = business_Definition;
	}

}
